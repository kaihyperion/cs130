---
layout: default
title: Homework 04
nav_exclude: True
---

# Homework 04 Instructions
Please follow the instructions in the <a href="https://docs.google.com/document/d/1oMfFIhi4CiE_xAENnDduwSJg8yE82zoK1dz3jL365Zo/edit?usp=sharing" target="_blank">Google Doc</a>. The files that are needed for homework 04 can be downloaded [here](../hw04.zip).

## Due
Sunday, May 5 at 11:59PM
